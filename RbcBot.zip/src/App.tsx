import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import GiveawaySection from './components/GiveawaySection';
import AdminPanel from './components/AdminPanel';
import Footer from './components/Footer';
import AboutPage from './components/pages/AboutPage';
import RulesPage from './components/pages/RulesPage';
import EventsPage from './components/pages/EventsPage';
import StaffPage from './components/pages/StaffPage';

interface Giveaway {
  id: string;
  title: string;
  description: string;
  prize: string;
  endDate: string;
  participants: number;
  isActive: boolean;
}

interface Page {
  id: string;
  title: string;
  slug: string;
  content: string;
  isActive: boolean;
  createdAt: string;
}

function App() {
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [currentPage, setCurrentPage] = useState('home');
  const [giveaways, setGiveaways] = useState<Giveaway[]>([]);
  const [customPages, setCustomPages] = useState<Page[]>([]);

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedGiveaways = localStorage.getItem('rbcGiveaways');
    if (savedGiveaways) {
      setGiveaways(JSON.parse(savedGiveaways));
    }

    const savedPages = localStorage.getItem('rbcCustomPages');
    if (savedPages) {
      setCustomPages(JSON.parse(savedPages));
    }
  }, []);

  // Save data to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('rbcGiveaways', JSON.stringify(giveaways));
  }, [giveaways]);

  useEffect(() => {
    localStorage.setItem('rbcCustomPages', JSON.stringify(customPages));
  }, [customPages]);

  const handleUpdateGiveaways = (updatedGiveaways: Giveaway[]) => {
    setGiveaways(updatedGiveaways);
  };

  const handleUpdatePages = (updatedPages: Page[]) => {
    setCustomPages(updatedPages);
  };

  const handleAdminToggle = () => {
    if (isAdminMode) {
      // Exit admin mode
      setIsAdminMode(false);
      setIsAuthenticated(false);
      setPasswordInput('');
      setCurrentPage('home');
    } else {
      // Enter admin mode - show password prompt
      setShowPasswordPrompt(true);
    }
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === 'Rbcadminpass2025') {
      setIsAuthenticated(true);
      setIsAdminMode(true);
      setShowPasswordPrompt(false);
      setPasswordInput('');
    } else {
      alert('❌ Incorrect password! Access denied, tiger!');
      setPasswordInput('');
    }
  };

  const handlePasswordCancel = () => {
    setShowPasswordPrompt(false);
    setPasswordInput('');
  };

  const handlePageChange = (page: string) => {
    setCurrentPage(page);
  };

  // Update document title
  useEffect(() => {
    document.title = 'RBC Community - The Ultimate Tiger\'s Den 🐅';
  }, []);

  const renderPage = () => {
    if (isAdminMode) {
      return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <AdminPanel 
            giveaways={giveaways} 
            onUpdateGiveaways={handleUpdateGiveaways}
            customPages={customPages}
            onUpdatePages={handleUpdatePages}
          />
        </div>
      );
    }

    switch (currentPage) {
      case 'about':
        return <AboutPage />;
      case 'rules':
        return <RulesPage />;
      case 'events':
        return <EventsPage />;
      case 'staff':
        return <StaffPage />;
      default:
        // Check if it's a custom page
        const customPage = customPages.find(page => page.slug === currentPage && page.isActive);
        if (customPage) {
          return (
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
              <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-3xl shadow-2xl p-8 border-4 border-orange-200">
                <h1 className="text-4xl font-black text-gray-800 mb-8 text-center">{customPage.title}</h1>
                <div className="prose prose-lg max-w-none text-gray-700" dangerouslySetInnerHTML={{ __html: customPage.content }} />
              </div>
            </div>
          );
        }
        // Default home page
        return (
          <>
            <Hero />
            <GiveawaySection giveaways={giveaways} />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header 
        isAdminMode={isAdminMode} 
        onToggleAdmin={handleAdminToggle}
        currentPage={currentPage}
        onPageChange={handlePageChange}
        customPages={customPages.filter(page => page.isActive)}
      />
      
      {/* Password Prompt Modal */}
      {showPasswordPrompt && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-gradient-to-br from-orange-100 to-yellow-100 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border-4 border-orange-300 relative overflow-hidden">
            {/* Tiger stripe decoration */}
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-500 to-yellow-500"></div>
            <div className="absolute top-4 left-0 w-full h-1 bg-black/20 transform -skew-y-2"></div>
            
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-xl">
                <span className="text-2xl">🔐</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-gray-800 mb-2">🐅 ADMIN ACCESS 🐅</h3>
              <p className="text-gray-600 font-semibold text-sm sm:text-base">Enter the secret tiger code to access the admin panel!</p>
            </div>
            
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <input
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="🔑 Enter admin password..."
                className="w-full p-3 sm:p-4 border-2 border-orange-300 rounded-xl focus:ring-4 focus:ring-orange-400 focus:border-orange-500 transition-all font-semibold text-gray-700 bg-white text-sm sm:text-base"
                autoFocus
              />
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-orange-500 to-yellow-500 text-white py-3 rounded-xl font-bold hover:from-orange-600 hover:to-yellow-600 transition-all duration-300 transform hover:scale-105 shadow-lg text-sm sm:text-base"
                >
                  🚀 Access Panel
                </button>
                <button
                  type="button"
                  onClick={handlePasswordCancel}
                  className="flex-1 bg-gray-500 text-white py-3 rounded-xl font-bold hover:bg-gray-600 transition-all duration-300 transform hover:scale-105 shadow-lg text-sm sm:text-base"
                >
                  ❌ Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {renderPage()}
      
      {!isAdminMode && <Footer />}
    </div>
  );
}

export default App;