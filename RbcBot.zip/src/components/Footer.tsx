import React from 'react';
import { Heart, Crown, ExternalLink, Users, Zap, Award, TrendingUp } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative bg-gradient-to-br from-gray-900 via-orange-900 to-black text-white py-12 sm:py-16 overflow-hidden">
      {/* Tiger stripe pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-4 bg-orange-500 transform -skew-y-2"></div>
        <div className="absolute top-8 left-0 w-full h-2 bg-yellow-500 transform skew-y-1"></div>
        <div className="absolute top-16 left-0 w-full h-6 bg-orange-600 transform -skew-y-3"></div>
        <div className="absolute bottom-16 left-0 w-full h-2 bg-yellow-400 transform skew-y-2"></div>
        <div className="absolute bottom-8 left-0 w-full h-4 bg-orange-500 transform -skew-y-1"></div>
        <div className="absolute bottom-0 left-0 w-full h-8 bg-yellow-500 transform skew-y-2"></div>
      </div>

      {/* Floating elements */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-20 h-20 bg-orange-500/20 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-32 h-32 bg-yellow-500/20 rounded-full blur-2xl animate-bounce"></div>
        <div className="absolute top-1/2 left-1/3 w-16 h-16 bg-orange-400/30 rounded-full blur-lg animate-ping"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-12">
          {/* Brand Section */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-4 mb-6">
              <div className="relative">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-yellow-400 via-orange-500 to-orange-700 rounded-full flex items-center justify-center shadow-2xl border-2 sm:border-4 border-yellow-300">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-orange-600 to-yellow-500 rounded-full flex items-center justify-center relative overflow-hidden">
                    {/* Tiger stripes */}
                    <div className="absolute inset-0 opacity-40">
                      <div className="absolute top-1 left-0 w-full h-0.5 bg-black transform -rotate-12"></div>
                      <div className="absolute top-3 left-0 w-full h-0.5 bg-black transform rotate-12"></div>
                      <div className="absolute bottom-3 left-0 w-full h-0.5 bg-black transform -rotate-12"></div>
                      <div className="absolute bottom-1 left-0 w-full h-0.5 bg-black transform rotate-12"></div>
                    </div>
                    <Crown className="w-4 h-4 sm:w-6 sm:h-6 text-white z-10" />
                  </div>
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 sm:w-6 sm:h-6 bg-green-500 rounded-full border-2 border-white animate-pulse"></div>
              </div>
              <div>
                <span className="text-2xl sm:text-3xl font-black bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
                  RBC COMMUNITY
                </span>
                <p className="text-orange-300 font-bold text-sm sm:text-base">🐅 The Ultimate Tiger's Den 🐅</p>
              </div>
            </div>
            <p className="text-gray-300 mb-6 text-base sm:text-lg leading-relaxed font-semibold">
              Welcome to the most <span className="text-orange-400 font-black">LEGENDARY</span> Discord community where tigers gather for 
              <span className="text-yellow-400 font-black"> EPIC giveaways</span>, incredible vibes, and unforgettable memories! 
              Join the pack and become part of something <span className="text-orange-400 font-black">EXTRAORDINARY</span>! 🔥
            </p>
            <div className="flex items-center space-x-3 text-orange-400">
              <Heart className="w-5 h-5 sm:w-6 sm:h-6 animate-pulse" />
              <span className="font-bold text-base sm:text-lg">Made with 🧡 by the RBC Tiger Pack</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl sm:text-2xl font-black mb-4 sm:mb-6 text-yellow-300 flex items-center space-x-2">
              <Zap className="w-5 h-5 sm:w-6 sm:h-6" />
              <span>🚀 Quick Links</span>
            </h3>
            <ul className="space-y-3 sm:space-y-4">
              <li>
                <a 
                  href="https://discord.gg/letsgo"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-300 hover:text-orange-400 transition-all duration-300 flex items-center space-x-2 sm:space-x-3 group font-semibold text-base sm:text-lg"
                >
                  <ExternalLink className="w-4 h-4 sm:w-5 sm:h-5 group-hover:rotate-12 transition-transform" />
                  <span>🎮 Join Discord Server</span>
                </a>
              </li>
              <li>
                <a href="#giveaways" className="text-gray-300 hover:text-yellow-400 transition-all duration-300 font-semibold text-base sm:text-lg">
                  🎁 Active Giveaways
                </a>
              </li>
              <li>
                <a href="#community" className="text-gray-300 hover:text-orange-400 transition-all duration-300 font-semibold text-base sm:text-lg">
                  📋 Community Rules
                </a>
              </li>
              <li>
                <a href="#events" className="text-gray-300 hover:text-yellow-400 transition-all duration-300 font-semibold text-base sm:text-lg">
                  🎉 Upcoming Events
                </a>
              </li>
            </ul>
          </div>

          {/* Community Stats */}
          <div>
            <h3 className="text-xl sm:text-2xl font-black mb-4 sm:mb-6 text-orange-300 flex items-center space-x-2">
              <Award className="w-5 h-5 sm:w-6 sm:h-6" />
              <span>📊 Tiger Stats</span>
            </h3>
            <div className="space-y-3 sm:space-y-4">
              <div className="bg-gradient-to-r from-orange-600/20 to-yellow-600/20 backdrop-blur-sm rounded-xl p-3 sm:p-4 border border-orange-400/30">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 font-semibold flex items-center space-x-2 text-sm sm:text-base">
                    <Users className="w-4 h-4 sm:w-5 sm:h-5" />
                    <span>Total Tigers:</span>
                  </span>
                  <span className="text-orange-400 font-black text-lg sm:text-xl">1,160</span>
                </div>
              </div>
              <div className="bg-gradient-to-r from-green-600/20 to-emerald-600/20 backdrop-blur-sm rounded-xl p-3 sm:p-4 border border-green-400/30">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 font-semibold flex items-center space-x-2 text-sm sm:text-base">
                    <Zap className="w-4 h-4 sm:w-5 sm:h-5 animate-pulse" />
                    <span>Online Now:</span>
                  </span>
                  <span className="text-green-400 font-black text-lg sm:text-xl animate-pulse">183</span>
                </div>
              </div>
              <div className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 backdrop-blur-sm rounded-xl p-3 sm:p-4 border border-purple-400/30">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 font-semibold flex items-center space-x-2 text-sm sm:text-base">
                    <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5" />
                    <span>Server Boosts:</span>
                  </span>
                  <span className="text-purple-400 font-black text-lg sm:text-xl">28</span>
                </div>
              </div>
              <div className="bg-gradient-to-r from-yellow-600/20 to-orange-600/20 backdrop-blur-sm rounded-xl p-3 sm:p-4 border border-yellow-400/30">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 font-semibold flex items-center space-x-2 text-sm sm:text-base">
                    <Heart className="w-4 h-4 sm:w-5 sm:h-5 animate-pulse" />
                    <span>Epic Moments:</span>
                  </span>
                  <span className="text-yellow-400 font-black text-lg sm:text-xl">∞</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t-2 border-gradient-to-r from-orange-600 to-yellow-600 mt-8 sm:mt-12 pt-6 sm:pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-gray-400 text-center md:text-left font-semibold text-sm sm:text-base">
              © 2024 RBC Community. All rights reserved. | Built with 🧡 and 🔥 for our amazing tiger family
            </p>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-orange-400">
                <Crown className="w-4 h-4 sm:w-5 sm:h-5 animate-bounce" />
                <span className="font-bold text-sm sm:text-base">Roar with Pride! 🐅</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}