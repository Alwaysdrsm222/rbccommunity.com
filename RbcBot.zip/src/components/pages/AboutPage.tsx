import React from 'react';
import { Crown, Users, Award, Heart, Zap, Shield } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="py-12 sm:py-16 bg-gradient-to-b from-orange-100 via-yellow-50 to-orange-100 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <div className="flex justify-center mb-6 sm:mb-8">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center shadow-2xl animate-bounce">
              <Crown className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
            </div>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-gray-800 mb-4 sm:mb-6">
            🐅 <span className="bg-gradient-to-r from-orange-600 to-yellow-500 bg-clip-text text-transparent">ABOUT</span>
            <br />
            <span className="bg-gradient-to-r from-yellow-500 to-orange-600 bg-clip-text text-transparent">RBC COMMUNITY</span> 🐅
          </h1>
          <p className="text-lg sm:text-xl lg:text-2xl text-gray-700 max-w-3xl mx-auto font-semibold">
            Discover the story behind the most <span className="text-orange-600 font-black">LEGENDARY</span> Discord community! 🔥
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 mb-12 sm:mb-16">
          <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-3xl p-6 sm:p-8 shadow-2xl border-4 border-orange-200">
            <div className="flex items-center space-x-4 mb-6">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center">
                <Heart className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-gray-800">Our Story</h2>
            </div>
            <p className="text-gray-700 text-base sm:text-lg leading-relaxed font-semibold mb-4">
              RBC Community was born from a simple dream - to create the most welcoming, exciting, and legendary Discord server where every member feels like family. What started as a small group of friends has grown into a thriving community of over 1,160 amazing tigers!
            </p>
            <p className="text-gray-700 text-base sm:text-lg leading-relaxed font-semibold">
              We believe in creating genuine connections, sharing epic moments, and making every day an adventure. Our community isn't just about Discord - it's about building lifelong friendships and creating memories that last forever.
            </p>
          </div>

          <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-3xl p-6 sm:p-8 shadow-2xl border-4 border-yellow-200">
            <div className="flex items-center space-x-4 mb-6">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full flex items-center justify-center">
                <Zap className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-gray-800">Our Mission</h2>
            </div>
            <p className="text-gray-700 text-base sm:text-lg leading-relaxed font-semibold mb-4">
              To provide the ultimate Discord experience where every tiger can roar with pride! We're committed to maintaining a positive, inclusive environment where creativity flourishes and friendships bloom.
            </p>
            <p className="text-gray-700 text-base sm:text-lg leading-relaxed font-semibold">
              Through epic giveaways, engaging events, and 24/7 good vibes, we're building more than just a server - we're creating a legendary community that stands the test of time.
            </p>
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-6 sm:p-8 border-4 border-orange-200 mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl font-black text-gray-800 text-center mb-8 sm:mb-12">
            🏆 What Makes Us Special 🏆
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            <div className="text-center group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-xl group-hover:scale-110 transition-transform duration-300">
                <Users className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-gray-800 mb-3 sm:mb-4">Amazing Community</h3>
              <p className="text-gray-600 font-semibold text-sm sm:text-base">Over 1,160 incredible tigers from around the world, all united by friendship and good vibes!</p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-xl group-hover:scale-110 transition-transform duration-300">
                <Award className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-gray-800 mb-3 sm:mb-4">Epic Giveaways</h3>
              <p className="text-gray-600 font-semibold text-sm sm:text-base">Regular giveaways featuring gaming gear, Discord Nitro, exclusive merch, and more amazing prizes!</p>
            </div>

            <div className="text-center group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-orange-600 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-xl group-hover:scale-110 transition-transform duration-300">
                <Shield className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-gray-800 mb-3 sm:mb-4">Safe Environment</h3>
              <p className="text-gray-600 font-semibold text-sm sm:text-base">Carefully moderated spaces ensuring everyone feels welcome, respected, and part of the tiger family!</p>
            </div>
          </div>
        </div>

        <div className="text-center bg-gradient-to-r from-orange-500 to-yellow-500 rounded-3xl p-8 sm:p-12 text-white shadow-2xl">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-4 sm:mb-6">Ready to Join the Pack? 🐅</h2>
          <p className="text-lg sm:text-xl lg:text-2xl mb-6 sm:mb-8 font-semibold">
            Become part of something extraordinary and experience the legendary RBC Community vibes!
          </p>
          <a
            href="https://discord.gg/letsgo"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-white text-orange-600 px-8 sm:px-12 py-4 sm:py-6 rounded-2xl font-black text-lg sm:text-xl shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-500 border-4 border-yellow-300"
          >
            🚀 JOIN NOW 🚀
          </a>
        </div>
      </div>
    </div>
  );
}