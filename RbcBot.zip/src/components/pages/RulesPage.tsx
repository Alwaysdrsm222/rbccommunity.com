import React from 'react';
import { Shield, AlertTriangle, Heart, Users, Zap, Crown } from 'lucide-react';

export default function RulesPage() {
  const rules = [
    {
      icon: Heart,
      title: "Be Respectful & Kind",
      description: "Treat every tiger with respect and kindness. We're all here to have fun and make friends!",
      color: "from-pink-500 to-red-500"
    },
    {
      icon: Users,
      title: "No Harassment or Bullying",
      description: "Zero tolerance for harassment, bullying, or discrimination of any kind. Everyone deserves to feel safe.",
      color: "from-blue-500 to-purple-500"
    },
    {
      icon: Shield,
      title: "Keep Content Appropriate",
      description: "No NSFW content, excessive profanity, or inappropriate material. Keep it family-friendly!",
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: Zap,
      title: "No Spam or Self-Promotion",
      description: "Avoid spamming messages or excessive self-promotion. Quality over quantity, tigers!",
      color: "from-yellow-500 to-orange-500"
    },
    {
      icon: AlertTriangle,
      title: "Follow Discord ToS",
      description: "All Discord Terms of Service and Community Guidelines apply. No exceptions!",
      color: "from-red-500 to-pink-500"
    },
    {
      icon: Crown,
      title: "Listen to Staff",
      description: "Respect our amazing staff team. They're here to help and keep the community awesome!",
      color: "from-purple-500 to-indigo-500"
    }
  ];

  return (
    <div className="py-12 sm:py-16 bg-gradient-to-b from-orange-100 via-yellow-50 to-orange-100 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <div className="flex justify-center mb-6 sm:mb-8">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center shadow-2xl animate-bounce">
              <Shield className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
            </div>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-gray-800 mb-4 sm:mb-6">
            📋 <span className="bg-gradient-to-r from-orange-600 to-yellow-500 bg-clip-text text-transparent">COMMUNITY</span>
            <br />
            <span className="bg-gradient-to-r from-yellow-500 to-orange-600 bg-clip-text text-transparent">RULES</span> 📋
          </h1>
          <p className="text-lg sm:text-xl lg:text-2xl text-gray-700 max-w-3xl mx-auto font-semibold">
            Simple guidelines to keep our <span className="text-orange-600 font-black">LEGENDARY</span> community awesome for everyone! 🐅
          </p>
        </div>

        <div className="bg-gradient-to-r from-orange-500 to-yellow-500 rounded-3xl p-6 sm:p-8 text-white shadow-2xl mb-8 sm:mb-12">
          <div className="text-center">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black mb-4">🐅 Welcome to the Tiger's Den! 🐅</h2>
            <p className="text-lg sm:text-xl font-semibold">
              These rules help us maintain the epic vibes that make RBC Community special. 
              Follow them, and you'll have an absolutely legendary time with us!
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 mb-12 sm:mb-16">
          {rules.map((rule, index) => {
            const IconComponent = rule.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border-4 border-orange-200 hover:scale-105 transition-all duration-300 group"
              >
                <div className="flex items-start space-x-4 sm:space-x-6">
                  <div className={`w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br ${rule.color} rounded-full flex items-center justify-center shadow-xl group-hover:animate-bounce`}>
                    <IconComponent className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl sm:text-2xl font-black text-gray-800 mb-3 sm:mb-4">
                      {index + 1}. {rule.title}
                    </h3>
                    <p className="text-gray-700 font-semibold text-base sm:text-lg leading-relaxed">
                      {rule.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-3xl p-6 sm:p-8 shadow-2xl border-4 border-yellow-200 mb-8 sm:mb-12">
          <div className="text-center">
            <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-xl">
              <AlertTriangle className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-gray-800 mb-4 sm:mb-6">⚠️ Rule Violations ⚠️</h2>
            <div className="text-left max-w-3xl mx-auto space-y-4">
              <p className="text-gray-700 font-semibold text-base sm:text-lg">
                <span className="text-orange-600 font-black">First Offense:</span> Friendly warning from our staff team
              </p>
              <p className="text-gray-700 font-semibold text-base sm:text-lg">
                <span className="text-orange-600 font-black">Second Offense:</span> Temporary mute or timeout
              </p>
              <p className="text-gray-700 font-semibold text-base sm:text-lg">
                <span className="text-orange-600 font-black">Serious/Repeated Violations:</span> Temporary or permanent ban
              </p>
              <p className="text-gray-700 font-semibold text-base sm:text-lg mt-6 p-4 bg-orange-100 rounded-xl border-2 border-orange-300">
                <span className="text-orange-600 font-black">Remember:</span> Our staff team is here to help! 
                If you have questions about the rules or need assistance, don't hesitate to reach out. 
                We want everyone to have an amazing time in our community! 🧡
              </p>
            </div>
          </div>
        </div>

        <div className="text-center bg-gradient-to-r from-orange-500 to-yellow-500 rounded-3xl p-8 sm:p-12 text-white shadow-2xl">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-4 sm:mb-6">Ready to Join the Pack? 🐅</h2>
          <p className="text-lg sm:text-xl lg:text-2xl mb-6 sm:mb-8 font-semibold">
            Follow these simple rules and become part of the most legendary Discord community!
          </p>
          <a
            href="https://discord.gg/letsgo"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-white text-orange-600 px-8 sm:px-12 py-4 sm:py-6 rounded-2xl font-black text-lg sm:text-xl shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-500 border-4 border-yellow-300"
          >
            🚀 JOIN NOW 🚀
          </a>
        </div>
      </div>
    </div>
  );
}