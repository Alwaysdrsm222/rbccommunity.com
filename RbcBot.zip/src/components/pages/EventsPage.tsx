import React from 'react';
import { Calendar, Clock, Users, Trophy, Gamepad2, Music, Gift } from 'lucide-react';

export default function EventsPage() {
  const upcomingEvents = [
    {
      id: 1,
      title: "🎮 Gaming Tournament Night",
      description: "Epic gaming battles with amazing prizes! Bring your A-game and compete with fellow tigers!",
      date: "2024-12-28",
      time: "8:00 PM EST",
      participants: "50+ Tigers",
      icon: Gamepad2,
      color: "from-blue-500 to-purple-500"
    },
    {
      id: 2,
      title: "🎵 Music Listening Party",
      description: "Share your favorite tracks and discover new music with the community! Good vibes only!",
      date: "2024-12-30",
      time: "7:00 PM EST",
      participants: "30+ Tigers",
      icon: Music,
      color: "from-pink-500 to-red-500"
    },
    {
      id: 3,
      title: "🎁 New Year Mega Giveaway",
      description: "Ring in 2025 with our biggest giveaway yet! Multiple winners, epic prizes!",
      date: "2024-12-31",
      time: "11:00 PM EST",
      participants: "All Tigers Welcome",
      icon: Gift,
      color: "from-yellow-500 to-orange-500"
    }
  ];

  const recurringEvents = [
    {
      title: "🐅 Tiger Talk Tuesday",
      description: "Weekly community discussions and Q&A sessions",
      schedule: "Every Tuesday, 8:00 PM EST",
      icon: Users
    },
    {
      title: "🏆 Weekend Warriors",
      description: "Gaming sessions and mini-tournaments",
      schedule: "Every Saturday, 6:00 PM EST",
      icon: Trophy
    },
    {
      title: "🎉 Movie Night",
      description: "Watch parties with the community",
      schedule: "Every Friday, 9:00 PM EST",
      icon: Calendar
    }
  ];

  return (
    <div className="py-12 sm:py-16 bg-gradient-to-b from-orange-100 via-yellow-50 to-orange-100 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <div className="flex justify-center mb-6 sm:mb-8">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center shadow-2xl animate-bounce">
              <Calendar className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
            </div>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-gray-800 mb-4 sm:mb-6">
            🎉 <span className="bg-gradient-to-r from-orange-600 to-yellow-500 bg-clip-text text-transparent">EPIC</span>
            <br />
            <span className="bg-gradient-to-r from-yellow-500 to-orange-600 bg-clip-text text-transparent">EVENTS</span> 🎉
          </h1>
          <p className="text-lg sm:text-xl lg:text-2xl text-gray-700 max-w-3xl mx-auto font-semibold">
            Join our <span className="text-orange-600 font-black">LEGENDARY</span> events and create unforgettable memories with the tiger pack! 🐅
          </p>
        </div>

        {/* Upcoming Events */}
        <div className="mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl font-black text-gray-800 text-center mb-8 sm:mb-12">
            🔥 Upcoming Events 🔥
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
            {upcomingEvents.map((event) => {
              const IconComponent = event.icon;
              return (
                <div
                  key={event.id}
                  className="bg-white rounded-3xl shadow-2xl overflow-hidden transform hover:scale-105 transition-all duration-500 border-4 border-orange-200 group"
                >
                  <div className={`bg-gradient-to-br ${event.color} p-6 sm:p-8 text-white relative overflow-hidden`}>
                    <div className="absolute inset-0 opacity-20">
                      <div className="absolute top-2 left-0 w-full h-1 bg-black transform -rotate-12"></div>
                      <div className="absolute top-6 left-0 w-full h-1 bg-black transform rotate-12"></div>
                      <div className="absolute bottom-6 left-0 w-full h-1 bg-black transform -rotate-12"></div>
                      <div className="absolute bottom-2 left-0 w-full h-1 bg-black transform rotate-12"></div>
                    </div>
                    
                    <div className="relative z-10">
                      <div className="flex items-center justify-between mb-4">
                        <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                          <IconComponent className="w-6 h-6 group-hover:animate-bounce" />
                        </div>
                        <span className="text-sm font-black bg-white/30 px-3 py-1 rounded-full backdrop-blur-sm border border-white/50">
                          UPCOMING
                        </span>
                      </div>
                      <h3 className="text-xl sm:text-2xl font-black mb-3 drop-shadow-lg">{event.title}</h3>
                      <p className="text-white/90 font-semibold text-sm sm:text-base">{event.description}</p>
                    </div>
                  </div>

                  <div className="p-6 sm:p-8">
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3 text-gray-700">
                        <div className="w-8 h-8 bg-gradient-to-br from-orange-400 to-yellow-400 rounded-full flex items-center justify-center">
                          <Calendar className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <div className="font-black text-sm sm:text-base">{new Date(event.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
                          <div className="text-xs sm:text-sm text-gray-500">Event Date</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3 text-gray-700">
                        <div className="w-8 h-8 bg-gradient-to-br from-yellow-400 to-orange-400 rounded-full flex items-center justify-center">
                          <Clock className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <div className="font-black text-sm sm:text-base">{event.time}</div>
                          <div className="text-xs sm:text-sm text-gray-500">Start Time</div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3 text-gray-700">
                        <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-emerald-400 rounded-full flex items-center justify-center">
                          <Users className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <div className="font-black text-sm sm:text-base">{event.participants}</div>
                          <div className="text-xs sm:text-sm text-gray-500">Expected Attendance</div>
                        </div>
                      </div>
                    </div>

                    <a
                      href="https://discord.gg/letsgo"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full mt-6 bg-gradient-to-r from-orange-500 to-yellow-500 text-white py-3 rounded-2xl font-black text-sm sm:text-base text-center block hover:from-orange-600 hover:to-yellow-600 transition-all duration-300 transform hover:scale-105 shadow-xl"
                    >
                      🎯 Join Event
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recurring Events */}
        <div className="mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl font-black text-gray-800 text-center mb-8 sm:mb-12">
            🔄 Regular Events 🔄
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {recurringEvents.map((event, index) => {
              const IconComponent = event.icon;
              return (
                <div
                  key={index}
                  className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-3xl p-6 sm:p-8 shadow-2xl border-4 border-orange-200 hover:scale-105 transition-all duration-300 group"
                >
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-xl group-hover:animate-bounce">
                      <IconComponent className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl sm:text-2xl font-black text-gray-800 mb-3 sm:mb-4">{event.title}</h3>
                    <p className="text-gray-700 font-semibold mb-4 text-sm sm:text-base">{event.description}</p>
                    <div className="bg-orange-200 rounded-xl p-3 border-2 border-orange-300">
                      <p className="text-orange-800 font-black text-sm sm:text-base">{event.schedule}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center bg-gradient-to-r from-orange-500 to-yellow-500 rounded-3xl p-8 sm:p-12 text-white shadow-2xl">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-4 sm:mb-6">Don't Miss Out! 🐅</h2>
          <p className="text-lg sm:text-xl lg:text-2xl mb-6 sm:mb-8 font-semibold">
            Join our Discord server to get notified about all upcoming events and be part of the action!
          </p>
          <a
            href="https://discord.gg/letsgo"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-white text-orange-600 px-8 sm:px-12 py-4 sm:py-6 rounded-2xl font-black text-lg sm:text-xl shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-500 border-4 border-yellow-300"
          >
            🚀 JOIN DISCORD 🚀
          </a>
        </div>
      </div>
    </div>
  );
}