import React from 'react';
import { Crown, Shield, Users, Star, Heart, Zap } from 'lucide-react';

export default function StaffPage() {
  const staffMembers = [
    {
      name: "TigerKing",
      role: "Server Owner",
      description: "The legendary founder who started it all! Always working to make RBC the best community possible.",
      icon: Crown,
      color: "from-yellow-500 to-orange-500",
      badge: "👑 FOUNDER"
    },
    {
      name: "AlphaStrike",
      role: "Head Administrator",
      description: "Keeps everything running smoothly and ensures all tigers feel welcome in our den!",
      icon: Shield,
      color: "from-red-500 to-pink-500",
      badge: "🛡️ HEAD ADMIN"
    },
    {
      name: "NightProwler",
      role: "Community Manager",
      description: "The heart of our community! Always organizing events and bringing tigers together.",
      icon: Heart,
      color: "from-purple-500 to-indigo-500",
      badge: "💜 COMMUNITY"
    },
    {
      name: "ThunderClaw",
      role: "Event Coordinator",
      description: "Master of epic events! From gaming tournaments to movie nights, they make it happen.",
      icon: Zap,
      color: "from-blue-500 to-cyan-500",
      badge: "⚡ EVENTS"
    },
    {
      name: "SilverFang",
      role: "Moderator",
      description: "Guardian of good vibes! Keeps our community safe and friendly for all tigers.",
      icon: Star,
      color: "from-green-500 to-emerald-500",
      badge: "⭐ MODERATOR"
    },
    {
      name: "GoldenMane",
      role: "Moderator",
      description: "Always ready to help! Known for their patience and dedication to our community.",
      icon: Users,
      color: "from-orange-500 to-yellow-500",
      badge: "🌟 MODERATOR"
    }
  ];

  return (
    <div className="py-12 sm:py-16 bg-gradient-to-b from-orange-100 via-yellow-50 to-orange-100 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <div className="flex justify-center mb-6 sm:mb-8">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center shadow-2xl animate-bounce">
              <Crown className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
            </div>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-gray-800 mb-4 sm:mb-6">
            👑 <span className="bg-gradient-to-r from-orange-600 to-yellow-500 bg-clip-text text-transparent">MEET THE</span>
            <br />
            <span className="bg-gradient-to-r from-yellow-500 to-orange-600 bg-clip-text text-transparent">STAFF TEAM</span> 👑
          </h1>
          <p className="text-lg sm:text-xl lg:text-2xl text-gray-700 max-w-3xl mx-auto font-semibold">
            The <span className="text-orange-600 font-black">LEGENDARY</span> team behind RBC Community's success! 🐅
          </p>
        </div>

        <div className="bg-gradient-to-r from-orange-500 to-yellow-500 rounded-3xl p-6 sm:p-8 text-white shadow-2xl mb-8 sm:mb-12">
          <div className="text-center">
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black mb-4">🐅 Our Amazing Team 🐅</h2>
            <p className="text-lg sm:text-xl font-semibold">
              These incredible tigers work tirelessly to make RBC Community the best place on Discord! 
              They're always here to help, support, and ensure everyone has an epic time.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-12 sm:mb-16">
          {staffMembers.map((member, index) => {
            const IconComponent = member.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-3xl shadow-2xl overflow-hidden transform hover:scale-105 transition-all duration-500 border-4 border-orange-200 group"
              >
                <div className={`bg-gradient-to-br ${member.color} p-6 sm:p-8 text-white relative overflow-hidden`}>
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute top-2 left-0 w-full h-1 bg-black transform -rotate-12"></div>
                    <div className="absolute top-6 left-0 w-full h-1 bg-black transform rotate-12"></div>
                    <div className="absolute bottom-6 left-0 w-full h-1 bg-black transform -rotate-12"></div>
                    <div className="absolute bottom-2 left-0 w-full h-1 bg-black transform rotate-12"></div>
                  </div>
                  
                  <div className="relative z-10 text-center">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm group-hover:animate-bounce">
                      <IconComponent className="w-8 h-8 sm:w-10 sm:h-10" />
                    </div>
                    <span className="inline-block text-xs sm:text-sm font-black bg-white/30 px-3 py-1 rounded-full backdrop-blur-sm border border-white/50 mb-4">
                      {member.badge}
                    </span>
                    <h3 className="text-xl sm:text-2xl font-black mb-2 drop-shadow-lg">{member.name}</h3>
                    <p className="text-lg font-bold text-white/90">{member.role}</p>
                  </div>
                </div>

                <div className="p-6 sm:p-8">
                  <p className="text-gray-700 font-semibold text-sm sm:text-base leading-relaxed text-center">
                    {member.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-3xl p-6 sm:p-8 shadow-2xl border-4 border-yellow-200 mb-8 sm:mb-12">
          <div className="text-center">
            <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-xl">
              <Heart className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-gray-800 mb-4 sm:mb-6">💝 Want to Help? 💝</h2>
            <div className="max-w-3xl mx-auto space-y-4">
              <p className="text-gray-700 font-semibold text-base sm:text-lg">
                Our staff team is always looking for dedicated tigers who want to help make our community even better! 
                If you're interested in joining our team, here's what we look for:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <div className="bg-orange-100 rounded-xl p-4 border-2 border-orange-300">
                  <h4 className="font-black text-orange-800 mb-2">✨ Active Community Member</h4>
                  <p className="text-orange-700 font-semibold text-sm">Regular participation and positive presence</p>
                </div>
                <div className="bg-yellow-100 rounded-xl p-4 border-2 border-yellow-300">
                  <h4 className="font-black text-yellow-800 mb-2">🤝 Helpful & Friendly</h4>
                  <p className="text-yellow-700 font-semibold text-sm">Always willing to assist other tigers</p>
                </div>
                <div className="bg-green-100 rounded-xl p-4 border-2 border-green-300">
                  <h4 className="font-black text-green-800 mb-2">⏰ Available & Reliable</h4>
                  <p className="text-green-700 font-semibold text-sm">Consistent presence and dependability</p>
                </div>
                <div className="bg-purple-100 rounded-xl p-4 border-2 border-purple-300">
                  <h4 className="font-black text-purple-800 mb-2">🎯 Passionate About RBC</h4>
                  <p className="text-purple-700 font-semibold text-sm">Genuine love for our community</p>
                </div>
              </div>
              <p className="text-gray-700 font-semibold text-base sm:text-lg mt-6 p-4 bg-orange-100 rounded-xl border-2 border-orange-300">
                <span className="text-orange-600 font-black">Ready to apply?</span> Reach out to any current staff member 
                in our Discord server! We'd love to hear from you and learn more about how you\'d like to contribute to our amazing community! 🧡
              </p>
            </div>
          </div>
        </div>

        <div className="text-center bg-gradient-to-r from-orange-500 to-yellow-500 rounded-3xl p-8 sm:p-12 text-white shadow-2xl">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-4 sm:mb-6">Join Our Family! 🐅</h2>
          <p className="text-lg sm:text-xl lg:text-2xl mb-6 sm:mb-8 font-semibold">
            Come meet our amazing staff team and become part of the RBC Community family!
          </p>
          <a
            href="https://discord.gg/letsgo"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-white text-orange-600 px-8 sm:px-12 py-4 sm:py-6 rounded-2xl font-black text-lg sm:text-xl shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-500 border-4 border-yellow-300"
          >
            🚀 JOIN DISCORD 🚀
          </a>
        </div>
      </div>
    </div>
  );
}