import React, { useState } from 'react';
import { Crown, Users, Gift, Shield, Menu, X, Home, Info, FileText, Calendar, UserCheck } from 'lucide-react';

interface Page {
  id: string;
  title: string;
  slug: string;
  content: string;
  isActive: boolean;
  createdAt: string;
}

interface HeaderProps {
  isAdminMode: boolean;
  onToggleAdmin: () => void;
  currentPage: string;
  onPageChange: (page: string) => void;
  customPages: Page[];
}

export default function Header({ isAdminMode, onToggleAdmin, currentPage, onPageChange, customPages }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigationItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'about', label: 'About', icon: Info },
    { id: 'rules', label: 'Rules', icon: FileText },
    { id: 'events', label: 'Events', icon: Calendar },
    { id: 'staff', label: 'Staff', icon: UserCheck },
    ...customPages.map(page => ({
      id: page.slug,
      label: page.title,
      icon: FileText
    }))
  ];

  const handleNavClick = (pageId: string) => {
    onPageChange(pageId);
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="relative bg-gradient-to-r from-orange-900 via-orange-600 to-yellow-500 shadow-2xl overflow-hidden">
      {/* Tiger Stripe Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-full h-4 bg-black transform -skew-y-2"></div>
        <div className="absolute top-8 left-0 w-full h-2 bg-black transform skew-y-1"></div>
        <div className="absolute top-16 left-0 w-full h-6 bg-black transform -skew-y-3"></div>
        <div className="absolute bottom-16 left-0 w-full h-2 bg-black transform skew-y-2"></div>
        <div className="absolute bottom-8 left-0 w-full h-3 bg-black transform -skew-y-1"></div>
        <div className="absolute bottom-0 left-0 w-full h-5 bg-black transform skew-y-2"></div>
      </div>
      
      {/* Animated Tiger Eyes */}
      <div className="absolute top-4 right-20 w-8 h-8 bg-yellow-400 rounded-full opacity-60 animate-pulse hidden lg:block"></div>
      <div className="absolute top-6 right-32 w-6 h-6 bg-orange-400 rounded-full opacity-40 animate-bounce hidden lg:block"></div>
      
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-400/10 to-transparent animate-pulse"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 lg:py-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 lg:space-x-6">
            {/* Tiger-themed Logo */}
            <div className="relative group cursor-pointer" onClick={() => handleNavClick('home')}>
              <div className="w-12 h-12 lg:w-20 lg:h-20 bg-gradient-to-br from-yellow-400 via-orange-500 to-orange-700 rounded-full flex items-center justify-center shadow-2xl transform group-hover:scale-110 transition-all duration-500 border-2 lg:border-4 border-yellow-300">
                <div className="w-10 h-10 lg:w-16 lg:h-16 bg-gradient-to-br from-orange-600 to-yellow-500 rounded-full flex items-center justify-center relative overflow-hidden">
                  {/* Tiger stripes on logo */}
                  <div className="absolute inset-0">
                    <div className="absolute top-1 lg:top-2 left-0 w-full h-0.5 lg:h-1 bg-black/30 transform -rotate-12"></div>
                    <div className="absolute top-2 lg:top-6 left-0 w-full h-0.5 lg:h-1 bg-black/30 transform rotate-12"></div>
                    <div className="absolute bottom-2 lg:bottom-6 left-0 w-full h-0.5 lg:h-1 bg-black/30 transform -rotate-12"></div>
                    <div className="absolute bottom-1 lg:bottom-2 left-0 w-full h-0.5 lg:h-1 bg-black/30 transform rotate-12"></div>
                  </div>
                  <Crown className="w-5 h-5 lg:w-10 lg:h-10 text-white z-10 drop-shadow-lg" />
                </div>
              </div>
              {/* Pulsing ring */}
              <div className="absolute inset-0 w-12 h-12 lg:w-20 lg:h-20 border-2 lg:border-4 border-yellow-400 rounded-full animate-ping opacity-30"></div>
              {/* Status indicator */}
              <div className="absolute -bottom-1 -right-1 w-4 h-4 lg:w-8 lg:h-8 bg-green-500 rounded-full border-2 lg:border-4 border-white shadow-lg flex items-center justify-center animate-bounce">
                <div className="w-1.5 h-1.5 lg:w-3 lg:h-3 bg-white rounded-full animate-pulse"></div>
              </div>
            </div>
            
            <div className="text-white">
              <h1 className="text-xl sm:text-2xl lg:text-4xl font-black drop-shadow-2xl bg-gradient-to-r from-yellow-200 to-orange-200 bg-clip-text text-transparent">
                RBC COMMUNITY
              </h1>
              <p className="text-xs sm:text-sm lg:text-lg text-orange-100 font-semibold tracking-wide">
                🐅 The Ultimate Tiger's Den 🐅
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6">
            {navigationItems.map((item) => {
              const IconComponent = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-bold transition-all duration-300 transform hover:scale-105 ${
                    currentPage === item.id
                      ? 'bg-white/30 text-white border-2 border-white/50'
                      : 'text-orange-100 hover:bg-white/20 hover:text-white'
                  }`}
                >
                  <IconComponent className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
          
          <div className="flex items-center space-x-2 lg:space-x-4">
            {/* Live indicator */}
            <div className="flex items-center space-x-1 lg:space-x-2 bg-red-500 px-2 lg:px-4 py-1 lg:py-2 rounded-full animate-pulse">
              <div className="w-2 h-2 lg:w-3 lg:h-3 bg-white rounded-full animate-ping"></div>
              <span className="text-white font-bold text-xs lg:text-sm">LIVE</span>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-white hover:bg-white/20 rounded-lg transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            
            <button
              onClick={onToggleAdmin}
              className={`px-3 lg:px-6 py-2 lg:py-3 rounded-xl font-bold transition-all duration-300 transform hover:scale-105 text-xs lg:text-base ${
                isAdminMode 
                  ? 'bg-red-600 hover:bg-red-700 text-white shadow-lg' 
                  : 'bg-white/20 hover:bg-white/30 text-white backdrop-blur-md border border-white/30'
              }`}
            >
              {isAdminMode ? (
                <div className="flex items-center space-x-1 lg:space-x-2">
                  <Shield className="w-4 h-4 lg:w-5 lg:h-5" />
                  <span className="hidden sm:inline">Exit Admin</span>
                  <span className="sm:hidden">Exit</span>
                </div>
              ) : (
                <span className="hidden sm:inline">Admin Panel</span>
              )}
              {!isAdminMode && <span className="sm:hidden">Admin</span>}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden absolute top-full left-0 right-0 bg-gradient-to-br from-orange-800 to-yellow-600 border-t-2 border-yellow-400 shadow-2xl z-50">
            <nav className="px-4 py-6 space-y-2">
              {navigationItems.map((item) => {
                const IconComponent = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl font-bold transition-all duration-300 ${
                      currentPage === item.id
                        ? 'bg-white/30 text-white border-2 border-white/50'
                        : 'text-orange-100 hover:bg-white/20 hover:text-white'
                    }`}
                  >
                    <IconComponent className="w-5 h-5" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}