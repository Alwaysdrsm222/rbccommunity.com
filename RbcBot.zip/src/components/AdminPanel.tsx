import React, { useState } from 'react';
import { Plus, Edit3, Trash2, Save, X, Shield, Crown, Lock, FileText, Settings, Gift as GiftIcon } from 'lucide-react';

interface Giveaway {
  id: string;
  title: string;
  description: string;
  prize: string;
  endDate: string;
  participants: number;
  isActive: boolean;
}

interface Page {
  id: string;
  title: string;
  slug: string;
  content: string;
  isActive: boolean;
  createdAt: string;
}

interface AdminPanelProps {
  giveaways: Giveaway[];
  onUpdateGiveaways: (giveaways: Giveaway[]) => void;
  customPages: Page[];
  onUpdatePages: (pages: Page[]) => void;
}

export default function AdminPanel({ giveaways, onUpdateGiveaways, customPages, onUpdatePages }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'giveaways' | 'pages'>('giveaways');
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    prize: '',
    endDate: '',
    slug: '',
    content: '',
  });

  // Giveaway functions
  const handleAddGiveaway = () => {
    if (!formData.title || !formData.description || !formData.prize || !formData.endDate) return;

    const newGiveaway: Giveaway = {
      id: Date.now().toString(),
      title: formData.title,
      description: formData.description,
      prize: formData.prize,
      endDate: formData.endDate,
      participants: Math.floor(Math.random() * 200) + 50,
      isActive: true,
    };

    onUpdateGiveaways([...giveaways, newGiveaway]);
    resetForm();
  };

  const handleEditGiveaway = (id: string) => {
    const giveaway = giveaways.find(g => g.id === id);
    if (giveaway) {
      setFormData({
        title: giveaway.title,
        description: giveaway.description,
        prize: giveaway.prize,
        endDate: giveaway.endDate,
        slug: '',
        content: '',
      });
      setEditingId(id);
    }
  };

  const handleUpdateGiveaway = () => {
    if (!editingId) return;

    const updatedGiveaways = giveaways.map(g =>
      g.id === editingId
        ? { ...g, title: formData.title, description: formData.description, prize: formData.prize, endDate: formData.endDate }
        : g
    );

    onUpdateGiveaways(updatedGiveaways);
    resetForm();
  };

  const handleDeleteGiveaway = (id: string) => {
    const updatedGiveaways = giveaways.filter(g => g.id !== id);
    onUpdateGiveaways(updatedGiveaways);
  };

  const toggleGiveawayStatus = (id: string) => {
    const updatedGiveaways = giveaways.map(g =>
      g.id === id ? { ...g, isActive: !g.isActive } : g
    );
    onUpdateGiveaways(updatedGiveaways);
  };

  // Page functions
  const handleAddPage = () => {
    if (!formData.title || !formData.slug || !formData.content) return;

    const newPage: Page = {
      id: Date.now().toString(),
      title: formData.title,
      slug: formData.slug.toLowerCase().replace(/\s+/g, '-'),
      content: formData.content,
      isActive: true,
      createdAt: new Date().toISOString(),
    };

    onUpdatePages([...customPages, newPage]);
    resetForm();
  };

  const handleEditPage = (id: string) => {
    const page = customPages.find(p => p.id === id);
    if (page) {
      setFormData({
        title: page.title,
        slug: page.slug,
        content: page.content,
        description: '',
        prize: '',
        endDate: '',
      });
      setEditingId(id);
    }
  };

  const handleUpdatePage = () => {
    if (!editingId) return;

    const updatedPages = customPages.map(p =>
      p.id === editingId
        ? { ...p, title: formData.title, slug: formData.slug.toLowerCase().replace(/\s+/g, '-'), content: formData.content }
        : p
    );

    onUpdatePages(updatedPages);
    resetForm();
  };

  const handleDeletePage = (id: string) => {
    const updatedPages = customPages.filter(p => p.id !== id);
    onUpdatePages(updatedPages);
  };

  const togglePageStatus = (id: string) => {
    const updatedPages = customPages.map(p =>
      p.id === id ? { ...p, isActive: !p.isActive } : p
    );
    onUpdatePages(updatedPages);
  };

  const resetForm = () => {
    setFormData({ title: '', description: '', prize: '', endDate: '', slug: '', content: '' });
    setIsAddingNew(false);
    setEditingId(null);
  };

  return (
    <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-3xl shadow-2xl p-6 sm:p-8 border-4 border-orange-200 relative overflow-hidden">
      {/* Tiger stripe decoration */}
      <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-500 to-yellow-500"></div>
      <div className="absolute top-4 left-0 w-full h-1 bg-black/10 transform -skew-y-1"></div>
      
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 sm:mb-8 space-y-4 sm:space-y-0">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center shadow-xl">
            <Shield className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-gray-800 flex items-center space-x-2">
              <Crown className="w-6 h-6 sm:w-8 sm:h-8 text-orange-500" />
              <span>🐅 ADMIN CONTROL PANEL 🐅</span>
            </h2>
            <p className="text-orange-600 font-semibold text-sm sm:text-base">Manage Epic Content</p>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4 mb-6 sm:mb-8">
        <button
          onClick={() => setActiveTab('giveaways')}
          className={`flex items-center space-x-2 px-4 sm:px-6 py-3 rounded-xl font-bold transition-all duration-300 transform hover:scale-105 ${
            activeTab === 'giveaways'
              ? 'bg-gradient-to-r from-orange-500 to-yellow-500 text-white shadow-lg'
              : 'bg-white/50 text-gray-700 hover:bg-white/70'
          }`}
        >
          <GiftIcon className="w-5 h-5" />
          <span>Giveaways</span>
        </button>
        <button
          onClick={() => setActiveTab('pages')}
          className={`flex items-center space-x-2 px-4 sm:px-6 py-3 rounded-xl font-bold transition-all duration-300 transform hover:scale-105 ${
            activeTab === 'pages'
              ? 'bg-gradient-to-r from-orange-500 to-yellow-500 text-white shadow-lg'
              : 'bg-white/50 text-gray-700 hover:bg-white/70'
          }`}
        >
          <FileText className="w-5 h-5" />
          <span>Pages</span>
        </button>
      </div>

      {/* Add New Button */}
      <div className="mb-6 sm:mb-8">
        <button
          onClick={() => setIsAddingNew(true)}
          className="w-full sm:w-auto bg-gradient-to-r from-orange-500 to-yellow-500 text-white px-6 py-3 rounded-xl flex items-center justify-center space-x-3 hover:from-orange-600 hover:to-yellow-600 transition-all duration-300 transform hover:scale-105 shadow-xl font-bold border-2 border-orange-300"
        >
          <Plus className="w-6 h-6" />
          <span>{activeTab === 'giveaways' ? 'Add Epic Giveaway' : 'Add New Page'}</span>
        </button>
      </div>

      {/* Add/Edit Form */}
      {(isAddingNew || editingId) && (
        <div className="bg-white rounded-2xl p-6 sm:p-8 mb-6 sm:mb-8 shadow-xl border-2 border-orange-200 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-400 to-yellow-400"></div>
          
          <h3 className="text-xl sm:text-2xl font-black mb-4 sm:mb-6 text-gray-800 flex items-center space-x-2">
            <Lock className="w-5 h-5 sm:w-6 sm:h-6 text-orange-500" />
            <span>
              {isAddingNew 
                ? (activeTab === 'giveaways' ? '🎁 Create New Giveaway' : '📄 Create New Page')
                : (activeTab === 'giveaways' ? '✏️ Edit Giveaway' : '✏️ Edit Page')
              }
            </span>
          </h3>
          
          {activeTab === 'giveaways' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
              <input
                type="text"
                placeholder="🏆 Giveaway Title (e.g., Epic Gaming Setup)"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full p-3 sm:p-4 border-2 border-orange-200 rounded-xl focus:ring-4 focus:ring-orange-300 focus:border-orange-400 transition-all font-semibold text-gray-700 bg-orange-50 text-sm sm:text-base"
              />
              <input
                type="text"
                placeholder="🎁 Prize Description (e.g., Gaming Setup Worth $500)"
                value={formData.prize}
                onChange={(e) => setFormData({ ...formData, prize: e.target.value })}
                className="w-full p-3 sm:p-4 border-2 border-yellow-200 rounded-xl focus:ring-4 focus:ring-yellow-300 focus:border-yellow-400 transition-all font-semibold text-gray-700 bg-yellow-50 text-sm sm:text-base"
              />
              <textarea
                placeholder="📝 Detailed Description (What makes this giveaway epic?)"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full p-3 sm:p-4 border-2 border-orange-200 rounded-xl focus:ring-4 focus:ring-orange-300 focus:border-orange-400 transition-all md:col-span-2 font-semibold text-gray-700 bg-orange-50 text-sm sm:text-base"
                rows={4}
              />
              <input
                type="datetime-local"
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                className="w-full p-3 sm:p-4 border-2 border-yellow-200 rounded-xl focus:ring-4 focus:ring-yellow-300 focus:border-yellow-400 transition-all md:col-span-2 font-semibold text-gray-700 bg-yellow-50 text-sm sm:text-base"
              />
            </div>
          ) : (
            <div className="space-y-4 sm:space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                <input
                  type="text"
                  placeholder="📄 Page Title (e.g., Community Guidelines)"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full p-3 sm:p-4 border-2 border-orange-200 rounded-xl focus:ring-4 focus:ring-orange-300 focus:border-orange-400 transition-all font-semibold text-gray-700 bg-orange-50 text-sm sm:text-base"
                />
                <input
                  type="text"
                  placeholder="🔗 Page Slug (e.g., community-guidelines)"
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  className="w-full p-3 sm:p-4 border-2 border-yellow-200 rounded-xl focus:ring-4 focus:ring-yellow-300 focus:border-yellow-400 transition-all font-semibold text-gray-700 bg-yellow-50 text-sm sm:text-base"
                />
              </div>
              <textarea
                placeholder="📝 Page Content (HTML supported)"
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                className="w-full p-3 sm:p-4 border-2 border-orange-200 rounded-xl focus:ring-4 focus:ring-orange-300 focus:border-orange-400 transition-all font-semibold text-gray-700 bg-orange-50 text-sm sm:text-base"
                rows={8}
              />
            </div>
          )}

          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4 mt-6 sm:mt-8">
            <button
              onClick={activeTab === 'giveaways' 
                ? (isAddingNew ? handleAddGiveaway : handleUpdateGiveaway)
                : (isAddingNew ? handleAddPage : handleUpdatePage)
              }
              className="bg-gradient-to-r from-green-500 to-green-600 text-white px-6 sm:px-8 py-3 rounded-xl flex items-center justify-center space-x-3 hover:from-green-600 hover:to-green-700 transition-all duration-300 transform hover:scale-105 shadow-lg font-bold text-sm sm:text-base"
            >
              <Save className="w-4 h-4 sm:w-5 sm:h-5" />
              <span>{isAddingNew ? '🚀 Create' : '💾 Update'}</span>
            </button>
            <button
              onClick={resetForm}
              className="bg-gradient-to-r from-gray-500 to-gray-600 text-white px-6 sm:px-8 py-3 rounded-xl flex items-center justify-center space-x-3 hover:from-gray-600 hover:to-gray-700 transition-all duration-300 transform hover:scale-105 shadow-lg font-bold text-sm sm:text-base"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
              <span>Cancel</span>
            </button>
          </div>
        </div>
      )}

      {/* Content List */}
      <div className="space-y-4 sm:space-y-6">
        {activeTab === 'giveaways' ? (
          giveaways.length === 0 ? (
            <div className="text-center py-12 sm:py-16">
              <div className="w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 bg-gradient-to-br from-orange-400 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-xl">
                <Plus className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-gray-600 mb-3 sm:mb-4">🐅 No Giveaways Yet 🐅</h3>
              <p className="text-gray-500 font-semibold text-sm sm:text-base">Create your first epic giveaway to get the tigers excited!</p>
            </div>
          ) : (
            giveaways.map((giveaway) => (
              <div
                key={giveaway.id}
                className={`border-2 rounded-2xl p-4 sm:p-6 transition-all duration-300 transform hover:scale-102 shadow-lg ${
                  giveaway.isActive 
                    ? 'border-green-300 bg-gradient-to-r from-green-50 to-emerald-50 shadow-green-200' 
                    : 'border-gray-300 bg-gradient-to-r from-gray-50 to-slate-50 shadow-gray-200'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-4 mb-3">
                      <h3 className="text-lg sm:text-xl font-black text-gray-800">{giveaway.title}</h3>
                      <span className={`px-3 sm:px-4 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-black border-2 w-fit ${
                        giveaway.isActive 
                          ? 'bg-green-200 text-green-800 border-green-300 animate-pulse' 
                          : 'bg-gray-200 text-gray-800 border-gray-300'
                      }`}>
                        {giveaway.isActive ? '🟢 LIVE' : '🔴 INACTIVE'}
                      </span>
                    </div>
                    <p className="text-gray-700 mb-3 font-semibold text-sm sm:text-base">{giveaway.description}</p>
                    <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-6 text-xs sm:text-sm text-gray-600">
                      <span className="flex items-center space-x-1">
                        <span className="font-bold">🏆 Prize:</span>
                        <span className="font-semibold">{giveaway.prize}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <span className="font-bold">📅 Ends:</span>
                        <span className="font-semibold">{new Date(giveaway.endDate).toLocaleDateString()}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <span className="font-bold">👥 Tigers:</span>
                        <span className="font-semibold text-orange-600">{giveaway.participants}</span>
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                    <button
                      onClick={() => toggleGiveawayStatus(giveaway.id)}
                      className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all duration-300 transform hover:scale-105 ${
                        giveaway.isActive 
                          ? 'bg-yellow-500 text-white hover:bg-yellow-600 shadow-lg' 
                          : 'bg-green-500 text-white hover:bg-green-600 shadow-lg'
                      }`}
                    >
                      {giveaway.isActive ? '⏸️ Pause' : '▶️ Activate'}
                    </button>
                    <button
                      onClick={() => handleEditGiveaway(giveaway.id)}
                      className="p-2 sm:p-3 text-blue-600 hover:bg-blue-100 rounded-lg transition-all duration-300 transform hover:scale-110"
                    >
                      <Edit3 className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                    <button
                      onClick={() => handleDeleteGiveaway(giveaway.id)}
                      className="p-2 sm:p-3 text-red-600 hover:bg-red-100 rounded-lg transition-all duration-300 transform hover:scale-110"
                    >
                      <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )
        ) : (
          customPages.length === 0 ? (
            <div className="text-center py-12 sm:py-16">
              <div className="w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 bg-gradient-to-br from-orange-400 to-yellow-400 rounded-full flex items-center justify-center mx-auto mb-4 sm:mb-6 shadow-xl">
                <FileText className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-gray-600 mb-3 sm:mb-4">📄 No Custom Pages Yet 📄</h3>
              <p className="text-gray-500 font-semibold text-sm sm:text-base">Create your first custom page to expand your community site!</p>
            </div>
          ) : (
            customPages.map((page) => (
              <div
                key={page.id}
                className={`border-2 rounded-2xl p-4 sm:p-6 transition-all duration-300 transform hover:scale-102 shadow-lg ${
                  page.isActive 
                    ? 'border-blue-300 bg-gradient-to-r from-blue-50 to-indigo-50 shadow-blue-200' 
                    : 'border-gray-300 bg-gradient-to-r from-gray-50 to-slate-50 shadow-gray-200'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-4 mb-3">
                      <h3 className="text-lg sm:text-xl font-black text-gray-800">{page.title}</h3>
                      <span className={`px-3 sm:px-4 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-black border-2 w-fit ${
                        page.isActive 
                          ? 'bg-blue-200 text-blue-800 border-blue-300' 
                          : 'bg-gray-200 text-gray-800 border-gray-300'
                      }`}>
                        {page.isActive ? '🟢 ACTIVE' : '🔴 INACTIVE'}
                      </span>
                    </div>
                    <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-6 text-xs sm:text-sm text-gray-600">
                      <span className="flex items-center space-x-1">
                        <span className="font-bold">🔗 Slug:</span>
                        <span className="font-semibold">/{page.slug}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <span className="font-bold">📅 Created:</span>
                        <span className="font-semibold">{new Date(page.createdAt).toLocaleDateString()}</span>
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-2 sm:gap-3">
                    <button
                      onClick={() => togglePageStatus(page.id)}
                      className={`px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-bold transition-all duration-300 transform hover:scale-105 ${
                        page.isActive 
                          ? 'bg-yellow-500 text-white hover:bg-yellow-600 shadow-lg' 
                          : 'bg-green-500 text-white hover:bg-green-600 shadow-lg'
                      }`}
                    >
                      {page.isActive ? '⏸️ Hide' : '▶️ Show'}
                    </button>
                    <button
                      onClick={() => handleEditPage(page.id)}
                      className="p-2 sm:p-3 text-blue-600 hover:bg-blue-100 rounded-lg transition-all duration-300 transform hover:scale-110"
                    >
                      <Edit3 className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                    <button
                      onClick={() => handleDeletePage(page.id)}
                      className="p-2 sm:p-3 text-red-600 hover:bg-red-100 rounded-lg transition-all duration-300 transform hover:scale-110"
                    >
                      <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )
        )}
      </div>
    </div>
  );
}