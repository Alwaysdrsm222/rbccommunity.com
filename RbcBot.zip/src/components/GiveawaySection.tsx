import React from 'react';
import { Gift, Clock, Users, Sparkles, Crown, Zap } from 'lucide-react';

interface Giveaway {
  id: string;
  title: string;
  description: string;
  prize: string;
  endDate: string;
  participants: number;
  isActive: boolean;
}

interface GiveawaySectionProps {
  giveaways: Giveaway[];
}

export default function GiveawaySection({ giveaways }: GiveawaySectionProps) {
  const activeGiveaways = giveaways.filter(g => g.isActive);

  const formatTimeRemaining = (endDate: string) => {
    const end = new Date(endDate);
    const now = new Date();
    const diff = end.getTime() - now.getTime();
    
    if (diff <= 0) return 'Ended';
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    return `${days}d ${hours}h left`;
  };

  return (
    <section id="giveaways" className="py-16 sm:py-24 bg-gradient-to-b from-orange-100 via-yellow-50 to-orange-100 relative overflow-hidden">
      {/* Tiger stripe background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-full h-6 bg-black transform -skew-y-2"></div>
        <div className="absolute top-20 left-0 w-full h-4 bg-black transform skew-y-1"></div>
        <div className="absolute top-40 left-0 w-full h-8 bg-black transform -skew-y-3"></div>
        <div className="absolute bottom-40 left-0 w-full h-4 bg-black transform skew-y-2"></div>
        <div className="absolute bottom-20 left-0 w-full h-6 bg-black transform -skew-y-1"></div>
        <div className="absolute bottom-0 left-0 w-full h-8 bg-black transform skew-y-3"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16 sm:mb-20">
          <div className="flex justify-center mb-6 sm:mb-8">
            <div className="relative">
              <div className="w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center shadow-2xl animate-bounce">
                <Gift className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 text-white" />
              </div>
              <Sparkles className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-yellow-500 absolute -top-1 sm:-top-2 -right-1 sm:-right-2 animate-spin" />
              <Crown className="w-6 h-6 sm:w-7 sm:h-7 lg:w-8 lg:h-8 text-orange-500 absolute -top-1 sm:-top-2 -left-1 sm:-left-2 animate-pulse" />
              <Zap className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-red-500 absolute -bottom-1 -right-1 animate-ping" />
            </div>
          </div>
          
          <h2 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-black text-gray-800 mb-4 sm:mb-6">
            🎁 <span className="bg-gradient-to-r from-orange-600 to-yellow-500 bg-clip-text text-transparent">LEGENDARY</span>
            <br />
            <span className="bg-gradient-to-r from-yellow-500 to-orange-600 bg-clip-text text-transparent">GIVEAWAYS</span> 🎁
          </h2>
          <p className="text-lg sm:text-xl lg:text-2xl text-gray-700 max-w-3xl mx-auto font-semibold px-4">
            🔥 Don't miss these <span className="text-orange-600 font-black">INSANE</span> prizes! 
            Join our Discord to enter and become a <span className="text-yellow-600 font-black">LEGEND</span>! 🔥
          </p>
        </div>

        {activeGiveaways.length === 0 ? (
          <div className="text-center py-16 sm:py-20">
            <div className="relative inline-block">
              <Gift className="w-24 h-24 sm:w-28 sm:h-28 lg:w-32 lg:h-32 text-gray-400 mx-auto mb-6 sm:mb-8" />
              <div className="absolute inset-0 w-24 h-24 sm:w-28 sm:h-28 lg:w-32 lg:h-32 border-4 border-gray-300 rounded-full animate-ping opacity-30 mx-auto"></div>
            </div>
            <h3 className="text-3xl sm:text-4xl font-black text-gray-600 mb-4 sm:mb-6">🐅 No Active Giveaways 🐅</h3>
            <p className="text-lg sm:text-xl text-gray-500 font-semibold px-4">The tigers are preparing something EPIC! Stay tuned for legendary prizes coming soon! 🔥</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 lg:gap-10">
            {activeGiveaways.map((giveaway, index) => (
              <div
                key={giveaway.id}
                className="group relative bg-white rounded-3xl shadow-2xl overflow-hidden transform hover:scale-105 transition-all duration-500 hover:shadow-3xl border-4 border-gradient-to-r from-orange-300 to-yellow-300"
              >
                {/* Animated background */}
                <div className="absolute inset-0 bg-gradient-to-br from-orange-400/10 to-yellow-400/10 group-hover:from-orange-400/20 group-hover:to-yellow-400/20 transition-all duration-500"></div>
                
                {/* Live badge */}
                <div className="absolute top-4 sm:top-6 right-4 sm:right-6 z-20">
                  <div className="bg-gradient-to-r from-red-500 to-red-600 text-white px-3 sm:px-4 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-black animate-pulse shadow-lg border-2 border-white">
                    🔴 LIVE
                  </div>
                </div>

                {/* Tiger stripe decoration */}
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-orange-500 to-yellow-500"></div>
                <div className="absolute top-4 left-0 w-full h-1 bg-black/20 transform -skew-y-2"></div>

                <div className="bg-gradient-to-br from-orange-500 via-orange-600 to-yellow-500 p-6 sm:p-8 text-white relative overflow-hidden">
                  {/* Background pattern */}
                  <div className="absolute inset-0 opacity-20">
                    <div className="absolute top-2 left-0 w-full h-1 bg-black transform -rotate-12"></div>
                    <div className="absolute top-6 left-0 w-full h-1 bg-black transform rotate-12"></div>
                    <div className="absolute bottom-6 left-0 w-full h-1 bg-black transform -rotate-12"></div>
                    <div className="absolute bottom-2 left-0 w-full h-1 bg-black transform rotate-12"></div>
                  </div>
                  
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-4 sm:mb-6">
                      <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                        <Gift className="w-5 h-5 sm:w-6 sm:h-6 animate-bounce" />
                      </div>
                      <span className="text-xs sm:text-sm font-black bg-white/30 px-3 sm:px-4 py-1 sm:py-2 rounded-full backdrop-blur-sm border border-white/50">
                        🏆 {giveaway.prize}
                      </span>
                    </div>
                    <h3 className="text-lg sm:text-xl lg:text-2xl font-black mb-3 sm:mb-4 drop-shadow-lg">{giveaway.title}</h3>
                    <p className="text-orange-100 font-semibold leading-relaxed text-sm sm:text-base">{giveaway.description}</p>
                  </div>
                </div>

                <div className="p-6 sm:p-8 relative">
                  <div className="flex flex-col sm:flex-row items-center justify-between mb-4 sm:mb-6 space-y-4 sm:space-y-0">
                    <div className="flex items-center space-x-3 text-gray-700">
                      <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-orange-400 to-yellow-400 rounded-full flex items-center justify-center">
                        <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                      </div>
                      <div>
                        <div className="font-black text-sm sm:text-base lg:text-lg">{formatTimeRemaining(giveaway.endDate)}</div>
                        <div className="text-xs sm:text-sm text-gray-500">Time Remaining</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 text-gray-700">
                      <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-yellow-400 to-orange-400 rounded-full flex items-center justify-center">
                        <Users className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                      </div>
                      <div>
                        <div className="font-black text-sm sm:text-base lg:text-lg">{giveaway.participants}</div>
                        <div className="text-xs sm:text-sm text-gray-500">Tigers Entered</div>
                      </div>
                    </div>
                  </div>

                  <a
                    href="https://discord.gg/letsgo"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-gradient-to-r from-orange-500 via-orange-600 to-yellow-500 text-white py-3 sm:py-4 rounded-2xl font-black text-base sm:text-lg text-center block hover:from-orange-600 hover:via-orange-700 hover:to-yellow-600 transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-2xl border-2 border-orange-300 relative overflow-hidden group"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 to-orange-400/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <span className="relative z-10 flex items-center justify-center space-x-2">
                      <Crown className="w-5 h-5 sm:w-6 sm:h-6" />
                      <span>🚀 ENTER NOW 🚀</span>
                      <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 animate-spin" />
                    </span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}