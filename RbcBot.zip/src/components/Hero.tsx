import React from 'react';
import { ExternalLink, Users, Zap, Award, Crown, Gift, TrendingUp } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-orange-900 via-orange-600 to-yellow-500 min-h-screen flex items-center overflow-hidden">
      {/* Tiger Stripe Background Pattern */}
      <div className="absolute inset-0 opacity-15">
        <div className="absolute top-0 left-0 w-full h-8 bg-black transform -skew-y-3"></div>
        <div className="absolute top-20 left-0 w-full h-4 bg-black transform skew-y-2"></div>
        <div className="absolute top-40 left-0 w-full h-12 bg-black transform -skew-y-4"></div>
        <div className="absolute top-80 left-0 w-full h-6 bg-black transform skew-y-3"></div>
        <div className="absolute bottom-80 left-0 w-full h-4 bg-black transform -skew-y-2"></div>
        <div className="absolute bottom-40 left-0 w-full h-8 bg-black transform skew-y-4"></div>
        <div className="absolute bottom-20 left-0 w-full h-6 bg-black transform -skew-y-3"></div>
        <div className="absolute bottom-0 left-0 w-full h-10 bg-black transform skew-y-2"></div>
      </div>

      {/* Floating Tiger Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-20 sm:w-40 h-20 sm:h-40 bg-gradient-to-br from-yellow-400/30 to-orange-500/30 rounded-full blur-2xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-32 sm:w-60 h-32 sm:h-60 bg-gradient-to-br from-orange-400/20 to-yellow-400/20 rounded-full blur-3xl animate-bounce"></div>
        <div className="absolute top-1/2 left-1/4 w-16 sm:w-32 h-16 sm:h-32 bg-yellow-300/40 rounded-full blur-xl animate-ping"></div>
        <div className="absolute top-1/3 right-1/4 w-12 sm:w-24 h-12 sm:h-24 bg-orange-400/50 rounded-full blur-lg animate-pulse"></div>
      </div>

      {/* Tiger Eyes Animation */}
      <div className="absolute top-32 right-32 hidden lg:block">
        <div className="flex space-x-4">
          <div className="w-12 h-12 bg-yellow-400 rounded-full relative animate-pulse">
            <div className="absolute inset-2 bg-black rounded-full">
              <div className="absolute inset-1 bg-yellow-300 rounded-full animate-ping"></div>
            </div>
          </div>
          <div className="w-12 h-12 bg-yellow-400 rounded-full relative animate-pulse">
            <div className="absolute inset-2 bg-black rounded-full">
              <div className="absolute inset-1 bg-yellow-300 rounded-full animate-ping"></div>
            </div>
          </div>
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20 z-10">
        <div className="text-center">
          {/* Main Logo with Tiger Theme */}
          <div className="mb-8 sm:mb-12 flex justify-center">
            <div className="relative group">
              <div className="w-24 h-24 sm:w-32 sm:h-32 lg:w-40 lg:h-40 bg-gradient-to-br from-yellow-300 via-orange-500 to-orange-700 rounded-full flex items-center justify-center shadow-2xl transform group-hover:scale-110 transition-all duration-700 border-4 sm:border-6 lg:border-8 border-yellow-200">
                <div className="w-20 h-20 sm:w-26 sm:h-26 lg:w-32 lg:h-32 bg-gradient-to-br from-orange-600 to-yellow-400 rounded-full flex items-center justify-center relative overflow-hidden">
                  {/* Tiger stripes */}
                  <div className="absolute inset-0">
                    <div className="absolute top-2 sm:top-3 lg:top-4 left-0 w-full h-1 sm:h-1.5 lg:h-2 bg-black/40 transform -rotate-12"></div>
                    <div className="absolute top-4 sm:top-6 lg:top-8 left-0 w-full h-0.5 sm:h-0.5 lg:h-1 bg-black/30 transform rotate-12"></div>
                    <div className="absolute top-6 sm:top-9 lg:top-12 left-0 w-full h-1 sm:h-1.5 lg:h-2 bg-black/40 transform -rotate-12"></div>
                    <div className="absolute bottom-6 sm:bottom-9 lg:bottom-12 left-0 w-full h-0.5 sm:h-0.5 lg:h-1 bg-black/30 transform rotate-12"></div>
                    <div className="absolute bottom-4 sm:bottom-6 lg:bottom-8 left-0 w-full h-1 sm:h-1.5 lg:h-2 bg-black/40 transform -rotate-12"></div>
                    <div className="absolute bottom-2 sm:bottom-3 lg:bottom-4 left-0 w-full h-0.5 sm:h-0.5 lg:h-1 bg-black/30 transform rotate-12"></div>
                  </div>
                  <div className="relative z-10 text-center">
                    <Crown className="w-6 h-6 sm:w-8 sm:h-8 lg:w-12 lg:h-12 text-white mb-1 sm:mb-2 mx-auto drop-shadow-lg" />
                    <span className="text-sm sm:text-lg lg:text-2xl font-black text-white drop-shadow-lg">RBC</span>
                  </div>
                </div>
              </div>
              {/* Animated rings */}
              <div className="absolute inset-0 w-24 h-24 sm:w-32 sm:h-32 lg:w-40 lg:h-40 border-2 sm:border-3 lg:border-4 border-yellow-300 rounded-full animate-ping opacity-40"></div>
              <div className="absolute inset-1 sm:inset-2 w-22 h-22 sm:w-28 sm:h-28 lg:w-36 lg:h-36 border-1 sm:border-2 border-orange-300 rounded-full animate-pulse opacity-60"></div>
              {/* Status indicators */}
              <div className="absolute -top-2 sm:-top-3 lg:-top-4 -right-2 sm:-right-3 lg:-right-4 w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 bg-green-500 rounded-full border-2 sm:border-3 lg:border-4 border-white shadow-xl flex items-center justify-center animate-bounce">
                <Users className="w-3 h-3 sm:w-4 sm:h-4 lg:w-6 lg:h-6 text-white" />
              </div>
              <div className="absolute -bottom-2 sm:-bottom-3 lg:-bottom-4 -left-2 sm:-left-3 lg:-left-4 w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 bg-red-500 rounded-full border-2 sm:border-3 lg:border-4 border-white shadow-xl flex items-center justify-center animate-pulse">
                <Gift className="w-3 h-3 sm:w-4 sm:h-4 lg:w-6 lg:h-6 text-white" />
              </div>
            </div>
          </div>

          <h1 className="text-4xl sm:text-6xl lg:text-7xl xl:text-9xl font-black text-white mb-6 sm:mb-8 drop-shadow-2xl">
            <span className="bg-gradient-to-r from-yellow-200 via-orange-200 to-yellow-300 bg-clip-text text-transparent animate-pulse">
              WELCOME TO
            </span>
            <br />
            <span className="text-3xl sm:text-5xl lg:text-6xl xl:text-8xl bg-gradient-to-r from-orange-200 via-yellow-200 to-orange-300 bg-clip-text text-transparent">
              🐅 RBC COMMUNITY 🐅
            </span>
          </h1>
          
          <p className="text-lg sm:text-xl lg:text-2xl xl:text-3xl text-orange-100 mb-12 sm:mb-16 max-w-4xl mx-auto leading-relaxed font-semibold px-4">
            Enter the <span className="text-yellow-200 font-black">Tiger's Den</span> - The most epic Discord community where 
            <span className="text-yellow-200 font-black"> legends are born</span>, giveaways are legendary, and the vibes are absolutely 
            <span className="text-yellow-200 font-black animate-pulse"> INSANE! 🔥</span>
          </p>

          <div className="flex flex-col sm:flex-row gap-6 sm:gap-8 justify-center items-center mb-16 sm:mb-20 px-4">
            <a
              href="https://discord.gg/letsgo"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative bg-gradient-to-r from-white to-yellow-100 text-orange-700 px-8 sm:px-12 py-4 sm:py-6 rounded-2xl font-black text-lg sm:text-xl shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-500 flex items-center space-x-3 sm:space-x-4 border-2 sm:border-4 border-yellow-300 w-full sm:w-auto justify-center"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-2xl blur opacity-30 group-hover:opacity-50 transition-opacity"></div>
              <ExternalLink className="w-6 h-6 sm:w-8 sm:h-8 group-hover:rotate-12 transition-transform relative z-10" />
              <span className="relative z-10">🚀 JOIN THE DEN 🚀</span>
            </a>
            
            <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 lg:space-x-8 text-white w-full sm:w-auto">
              <div className="flex items-center space-x-3 bg-white/20 backdrop-blur-md px-4 sm:px-6 py-3 rounded-xl border border-white/30 w-full sm:w-auto justify-center">
                <Users className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-300" />
                <div>
                  <div className="font-black text-lg sm:text-xl">1,160</div>
                  <div className="text-xs sm:text-sm text-orange-200">Tigers</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white/20 backdrop-blur-md px-4 sm:px-6 py-3 rounded-xl border border-white/30 w-full sm:w-auto justify-center">
                <Zap className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-300 animate-pulse" />
                <div>
                  <div className="font-black text-lg sm:text-xl text-green-300">183</div>
                  <div className="text-xs sm:text-sm text-orange-200">Online</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white/20 backdrop-blur-md px-4 sm:px-6 py-3 rounded-xl border border-white/30 w-full sm:w-auto justify-center">
                <TrendingUp className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-300 animate-bounce" />
                <div>
                  <div className="font-black text-lg sm:text-xl text-purple-300">28</div>
                  <div className="text-xs sm:text-sm text-orange-200">Boosts</div>
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto px-4">
            <div className="group relative bg-gradient-to-br from-orange-600/80 to-yellow-500/80 backdrop-blur-xl rounded-3xl p-6 sm:p-8 text-white hover:from-orange-500/90 hover:to-yellow-400/90 transition-all duration-500 transform hover:scale-105 border-2 border-yellow-300/50">
              <div className="absolute inset-0 bg-gradient-to-br from-yellow-400/20 to-orange-500/20 rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <Award className="w-12 h-12 sm:w-16 sm:h-16 text-yellow-200 mx-auto mb-4 sm:mb-6 group-hover:animate-bounce" />
              <h3 className="text-xl sm:text-2xl font-black mb-3 sm:mb-4">🏆 EPIC GIVEAWAYS</h3>
              <p className="text-orange-100 text-base sm:text-lg leading-relaxed">Win legendary prizes that'll make other communities jealous! From gaming gear to Discord Nitro - we've got it all!</p>
            </div>
            
            <div className="group relative bg-gradient-to-br from-yellow-600/80 to-orange-500/80 backdrop-blur-xl rounded-3xl p-6 sm:p-8 text-white hover:from-yellow-500/90 hover:to-orange-400/90 transition-all duration-500 transform hover:scale-105 border-2 border-orange-300/50">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-400/20 to-yellow-500/20 rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <Users className="w-12 h-12 sm:w-16 sm:h-16 text-orange-200 mx-auto mb-4 sm:mb-6 group-hover:animate-spin" />
              <h3 className="text-xl sm:text-2xl font-black mb-3 sm:mb-4">🔥 CHILL VIBES</h3>
              <p className="text-yellow-100 text-base sm:text-lg leading-relaxed">The most relaxed and friendly tigers you'll ever meet! No drama, just pure good vibes and legendary conversations!</p>
            </div>
            
            <div className="group relative bg-gradient-to-br from-orange-700/80 to-yellow-600/80 backdrop-blur-xl rounded-3xl p-6 sm:p-8 text-white hover:from-orange-600/90 hover:to-yellow-500/90 transition-all duration-500 transform hover:scale-105 border-2 border-yellow-400/50">
              <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/20 to-orange-400/20 rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <Zap className="w-12 h-12 sm:w-16 sm:h-16 text-yellow-300 mx-auto mb-4 sm:mb-6 group-hover:animate-pulse" />
              <h3 className="text-xl sm:text-2xl font-black mb-3 sm:mb-4">⚡ ACTIVE 24/7</h3>
              <p className="text-orange-100 text-base sm:text-lg leading-relaxed">Round-the-clock action with tigers from every timezone! There's always someone online ready to chat and have fun!</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}